import boto3
import requests
import json
from requests_aws4auth import AWS4Auth

credentials = boto3.Session().get_credentials()
es_client = boto3.client("es")
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, 'us-east-1', "es", session_token=credentials.token)


def lambda_handler(event, context):
    request_type = event['RequestType']
    if request_type == 'Create':
        return on_create(event)
    if request_type == 'Update':
        return on_update(event)
    if request_type == 'Delete':
        return json.dumps({'Data': {'Status': "SUCCESS"}})
    return json.dumps({'PhysicalResourceId': event['LogicalResourceId'], 'Status': 'SUCCESS'})


def on_create(event):
    post_to_kibana(event)
    return json.dumps({'Data': {'Status': "SUCCESS"}})


def post_to_kibana(event):
    props = event['ResourceProperties']
    requests_props = props['requests']
    print(event)
    url = requests_props['url']
    create_index(url, 'infineon-sensors')
    create_index(url, 'infineon-as')


def create_index(url, name):
    new_url = "https://" + url + '/' + name
    try:
        with open(name + '.json', 'r') as j:
            d = json.loads(json.dumps(j.read()))
        resp = requests.put(
            new_url, data=d,
            auth=awsauth,
            headers={'host': url, 'Content-Type': 'application/json'})
        print(resp.content)
    except requests.exceptions.ConnectionError as e:
        print('Connection refused')
        print(e)


def on_update(event):
    post_to_kibana(event)
    return json.dumps({'PhysicalResourceId': event['LogicalResourceId'], 'Status': 'SUCCESS'})
