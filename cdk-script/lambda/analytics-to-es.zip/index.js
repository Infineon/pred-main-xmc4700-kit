let AWS = require('aws-sdk');
let path = require('path');
let region = process.env.AWS_REGION;
let domain = process.env.AWS_DOMAIN;

/* == Globals == */
let esDomain = {
    region: region,
    endpoint: domain,
    index: 'infineon-as',
    doctype: '_doc'
};
let endpoint = new AWS.Endpoint(esDomain.endpoint);
let creds = new AWS.EnvironmentCredentials('AWS');

exports.handler = async (event, context) => {
    let success = 0;
    let failure = 0;
    const output = event.records.map((record) => {

        const recordData = Buffer.from(record.data, 'base64').toString();
        console.log("decoded", recordData)
        try {
            let result = JSON.parse(recordData);

            result['approximateArrivalTime'] = new Date().toISOString();
            let doc = JSON.stringify(result);
            postToES(doc);

            success++;
            return {
                recordId: record.recordId,
                result: 'Ok',
            };
        } catch (err) {
            failure++;
            return {
                recordId: record.recordId,
                result: 'DeliveryFailed',
            };
        }
    });
    console.log(`Successful delivered records ${success}, Failed delivered records ${failure}.`);
    return { records: output };
};

/*
 * Post the given document to Elasticsearch
 */
function postToES(doc) {
    let req = new AWS.HttpRequest(endpoint);
    req.method = 'POST';
    req.path = path.join('/', esDomain.index, esDomain.doctype);
    req.region = esDomain.region;
    req.headers['presigned-expires'] = false;
    req.headers['Host'] = endpoint.host;
    req.headers['Content-Type'] = ['application/json'];
    req.body = doc;

    let signer = new AWS.Signers.V4(req , 'es');  // es: service code
    signer.addAuthorization(creds, new Date());

    let send = new AWS.NodeHttpClient();
    send.handleRequest(req, null, function(httpResp) {
        let respBody = '';
        console.log(respBody);
        httpResp.on('data', function (chunk) {
            respBody += chunk;
        });
        httpResp.on('end', function (chunk) {
            console.log(doc);
            console.log('send time: %o %o',  new Date().getTime(), respBody);
            req.shouldKeepAlive = false;
        });
    }, function(err) {
        console.log('Error: ' + err);
        try {
            creds = new AWS.EnvironmentCredentials('AWS');
        } catch (e) {
            console.log('can\'t refresh signature creds: ' + e);
        }

    });
}
