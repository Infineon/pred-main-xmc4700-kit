import boto3
import requests
import json
from requests_aws4auth import AWS4Auth

credentials = boto3.Session().get_credentials()
es_client = boto3.client("es")
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, 'us-east-1', "es", session_token=credentials.token)


def lambda_handler(event, context):
    request_type = event['RequestType']
    if request_type == 'Create':
        return on_create(event)
    if request_type == 'Update':
        return on_update(event)
    if request_type == 'Delete':
        return json.dumps({'Data': {'Status': "SUCCESS"}})
    return json.dumps({'PhysicalResourceId': event['LogicalResourceId'], 'Status': 'SUCCESS'})


def on_create(event):
    post_to_kibana(event)
    return json.dumps({'Data': {'Status': "SUCCESS"}})


def post_to_kibana(event):
    props = event['ResourceProperties']
    requests_props = props['requests']
    print(event)
    url = requests_props['url']
    new_url = "https://" + url + '/_plugin/kibana/api/saved_objects/_import'
    try:
        files = {'file': open('visualizations.ndjson', 'rb')}

        resp1 = requests.post(
            new_url,
            auth=awsauth, files=files,
            headers={'host': url, 'kbn-xsrf': 'true'})
        print(resp1.content)
    except requests.exceptions.ConnectionError as e:
        print('Connection refused')
        print(e)


def on_update(event):
    post_to_kibana(event)
    return json.dumps({'PhysicalResourceId': event['LogicalResourceId'], 'Status': 'SUCCESS'})
